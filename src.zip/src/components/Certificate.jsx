import html2canvas from "html2canvas";

export async function downloadCertificate(ref, setDownloading) {
  if (!ref.current) return;
  setDownloading(true);
  const canvas = await html2canvas(ref.current);
  const link = document.createElement("a");
  link.download = "certificaat.png";
  link.href = canvas.toDataURL();
  link.click();
  setDownloading(false);
}
