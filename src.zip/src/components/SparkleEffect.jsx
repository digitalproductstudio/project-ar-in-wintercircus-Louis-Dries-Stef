import { Sparkles } from "@react-three/drei";

export default function SparkleEffect() {
  return (
    <Sparkles
      count={30}
      scale={2}
      speed={0.4}
      size={3}
      color="#FFD700"
    />
  );
}
