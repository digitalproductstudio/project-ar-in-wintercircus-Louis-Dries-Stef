export default function TaskList({ tasks, onTaskClick }) {
  return (
    <div className="task-list">
      {tasks.map(task => (
        <div key={task.id} onClick={() => onTaskClick(task)}>
          <img src={task.image} alt={task.name} />
          <p>{task.name}</p>
        </div>
      ))}
    </div>
  );
}
