import { useState, useRef, useEffect } from "react";
import { Canvas } from "@react-three/fiber";
import { Environment, OrbitControls } from "@react-three/drei";
import TemboModel from "./TemboModel";
import SparkleEffect from "./SparkleEffect";
import TaskList from "./TaskList";
import html2canvas from "html2canvas";
import { useWindowSize } from "../hooks/useWindowSize";

export default function GameScreen() {
  const [tasks, setTasks] = useState([
    { id: 1, name: "Was Tembo", done: false, image: "./sponge.png" },
    { id: 2, name: "Voeder Tembo", done: false, image: "./food.png" },
    { id: 3, name: "Verzamel voedsel", done: false, image: "./basket.png" },
  ]);
  const [playerName, setPlayerName] = useState("");
  const [showCertificate, setShowCertificate] = useState(false);
  const certificateRef = useRef(null);
  const [width] = useWindowSize();
  const [activeMode, setActiveMode] = useState(null);
  const [cleaningProgress, setCleaningProgress] = useState(0);
  const [feedingGameProgress, setFeedingGameProgress] = useState(0);
  const [bringingGameProgress, setBringingGameProgress] = useState(0);
  const [availableFood, setAvailableFood] = useState([]);
  const [fallingItems, setFallingItems] = useState([]);
  const [isDrawing, setIsDrawing] = useState(false);
  const [showSparkles, setShowSparkles] = useState(false);
  const canvasRef = useRef(null);
  const [isDownloading, setIsDownloading] = useState(false);

  const weetjes = [
    "het wintercircus vroeger een grote garage was? Hier stonden toen heel veel auto’s net een museum",
    "Lang geleden, in 1894, werd er in Gent een speciaal gebouw gemaakt waar het altijd circus kon zijn, zelfs in de winter.",
    "Tembo vroeger in de dierentuin van Gent woonde? Veel kinderen gingen naar hem kijken. Hij was heel bekend en iedereen vond hem leuk.",
    "Toen de dierentuin dichtging, moest Tembo verhuizen naar een andere dierentuin. Veel mensen vonden dat jammer, want ze waren dol op hem.",
  ];
  const [activeWeetje, setActiveWeetje] = useState(null);

  const allDone = tasks.every((task) => task.done);

  function handleTaskClick(task) {
    if (task.name === "Was Tembo") setActiveMode("cleaning");
    else if (task.name === "Voeder Tembo") setActiveMode("feeding");
    else if (task.name === "Verzamel voedsel") setActiveMode("bringing");
  }

  function completeTask(taskName) {
    setTasks((prev) =>
      prev.map((task) =>
        task.name === taskName ? { ...task, done: true } : task
      )
    );
    setActiveMode(null);
    setShowSparkles(true);
    setTimeout(() => setShowSparkles(false), 2000);
  }

  async function downloadCertificate() {
    if (!certificateRef.current) return;
    setIsDownloading(true);
    const canvas = await html2canvas(certificateRef.current);
    const link = document.createElement("a");
    link.download = "Tembo_Certificaat.png";
    link.href = canvas.toDataURL();
    link.click();
    setIsDownloading(false);
  }

  function handleDraw(e) {
    if (!isDrawing || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    ctx.clearRect(x - 15, y - 15, 30, 30);
  }

  return (
    <div className="game-screen">
      <h1>Welkom bij Tembo's Avontuur</h1>

      {!showCertificate && (
        <>
          <TaskList tasks={tasks} onTaskClick={handleTaskClick} />

          {activeMode === "cleaning" && (
            <div className="cleaning-mode">
              <canvas
                ref={canvasRef}
                width={400}
                height={300}
                onMouseDown={() => setIsDrawing(true)}
                onMouseUp={() => {
                  setIsDrawing(false);
                  completeTask("Was Tembo");
                }}
                onMouseMove={handleDraw}
              />
            </div>
          )}

          {activeMode === "feeding" && (
            <div className="feeding-mode">
              <p>Sleep het voedsel naar Tembo om hem te voeden!</p>
              <button onClick={() => completeTask("Voeder Tembo")}>Voer</button>
            </div>
          )}

          {activeMode === "bringing" && (
            <div className="bringing-mode">
              <p>Verzamel het voedsel voor Tembo!</p>
              <button onClick={() => completeTask("Verzamel voedsel")}>Verzamel</button>
            </div>
          )}
        </>
      )}

      {allDone && !showCertificate && (
        <div>
          <h2>Proficiat! Je hebt alle taken voltooid.</h2>
          <input
            type="text"
            placeholder="Jouw naam"
            value={playerName}
            onChange={(e) => setPlayerName(e.target.value)}
          />
          <button onClick={() => setShowCertificate(true)}>Toon certificaat</button>
        </div>
      )}

      {showCertificate && (
        <div>
          <div ref={certificateRef} className="certificate">
            <h2>Certificaat</h2>
            <p>{playerName}, je hebt Tembo fantastisch geholpen!</p>
          </div>
          <button onClick={downloadCertificate} disabled={isDownloading}>
            {isDownloading ? "Downloaden..." : "Download certificaat"}
          </button>
        </div>
      )}

      <Canvas style={{ height: "400px", width: "100%" }}>
        <ambientLight intensity={0.5} />
        <Environment preset="sunset" />
        <OrbitControls />
        <TemboModel screenWidth={width} />
        {showSparkles && <SparkleEffect />}
      </Canvas>
    </div>
  );
}