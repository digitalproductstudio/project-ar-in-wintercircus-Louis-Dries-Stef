import GameScreen from "./components/GameScreen.jsx";

export default function Game() {
  return <GameScreen />;
}
