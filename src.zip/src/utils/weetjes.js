export const weetjes = [
  "het wintercircus vroeger een grote garage was?...",
  "Lang geleden, in 1894, werd er in Gent...",
  "Tembo vroeger in de dierentuin van Gent woonde?...",
  "Toen de dierentuin dichtging, moest Tembo verhuizen...",
];
